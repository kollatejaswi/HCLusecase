package com.hcl.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.domain.TravelUser;
import com.hcl.service.TravelUserService;

@Controller
public class TravelUserController {
  TravelUserService service;
@Autowired
public TravelUserController(TravelUserService service) {
	super();
	this.service = service;
}
@RequestMapping(value={"/submituser"}, method = RequestMethod.POST)
public String getInsert(HttpServletRequest request,Model model)
{
	Integer id=(Integer)request.getAttribute("id");
	String firstname=request.getParameter("firstname");
	String middlename=request.getParameter("middlename");
	String lastname=request.getParameter("lastname");
	String address=request.getParameter("address");
	String contactno=request.getParameter("contactno");
	String checkin=request.getParameter("checkin");
	String checkout=request.getParameter("checkout");
	TravelUser t=new TravelUser();
	t.setTravel_id(id);
	t.setFirstname(firstname);
	t.setMiddlename(middlename);
	t.setLastname(lastname);
	t.setAddress(address);
	t.setContactno(contactno);
	t.setCheckin(checkin);
	t.setCheckout(checkout);
	Integer i=service.insertTravel(t);
	 String url=null;
	 if(i!=null)
	 {
	     url="redirect:/success";
	 }
	 else
	 {
		 model.addAttribute("msg","not inserted");
		 url="redirect:/";
	 }
	 return url;
}
}
