package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.domain.Room;
import com.hcl.service.RoomService;

@Controller
public class RoomController {
	private RoomService service;
	public RoomController() {
		// TODO Auto-generated constructor stub
	}
	@Autowired
	public RoomController(RoomService service) {
		super();
		this.service = service;
	}

	public RoomService getService() {
		return service;
	}
	public void setService(RoomService service) {
		this.service = service;
	}
	@RequestMapping(value="/makeareservation", method = RequestMethod.GET)
	 public String getRoom(Model model)
	 {
		List<Room> room=service.getAll();
		model.addAttribute("listroom", room);
		return "res";
	 }

}
