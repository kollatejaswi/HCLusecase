package com.hcl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.domain.Admin;
import com.hcl.domain.Travel;
import com.hcl.service.AdminService;
import java.util.List;

@Controller
public class AdminController {
   AdminService service;
@Autowired
public AdminController(AdminService service) {
	super();
	this.service = service;
}
@RequestMapping(value={"/login"}, method = RequestMethod.POST)
public String getInsert(HttpServletRequest request,Model model)
{
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	 Admin a=new Admin(username,password);
	 boolean b=service.login(a);
	 String url=null;
	 if(b)
	 {
		 HttpSession session=request.getSession();
		 session.setAttribute("name",username );
	     url="redirect:/adminpage";
	 }
	 else
	 {
		 model.addAttribute("msg","invalid credentials");
		 url="redirect:/";
	 }
	 return url;
}
@RequestMapping(value="/account", method = RequestMethod.GET)
public String getAccount(Model model)
{
	List<Admin> list=service.getAll();
	model.addAttribute("admin",list);
	 return "account";
}
@RequestMapping(value="/new", method = RequestMethod.GET)
public String getForm(Model model)
{
	
	 return "adminform";
}
@RequestMapping(value={"/addadmin"}, method = RequestMethod.POST)
public String getInsertAdmin(HttpServletRequest request,Model model)
{
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	 Admin a=new Admin(username,password);
	 Integer i=service.insert(a);
	 String url=null;
	 if(i!=null)
	 {
		 
	     url="redirect:/account";
	 }
	 else
	 {
		 model.addAttribute("msg","please fill again");
		 url="redirect:/adminpage";
	 }
	 return url;
}
@RequestMapping(value = "/delete", method = RequestMethod.GET)
public ModelAndView deleteEmployee(HttpServletRequest request) {
    int employeeId = Integer.parseInt(request.getParameter("id"));
    service.delete(employeeId);
    return new ModelAndView("redirect:/account");
}
@RequestMapping(value = "/edit", method = RequestMethod.GET)
public String editEmployee(HttpServletRequest request,Model model) {
    int employeeId = Integer.parseInt(request.getParameter("id"));
   Admin admin= service.getAdmin(employeeId);
   model.addAttribute("command", admin);
    return "editform";
}

@RequestMapping(value="/updateadmin", method = RequestMethod.POST)
public String getUpdatetAdmin(@Valid @ModelAttribute("admin") Admin admin,BindingResult br)
{
	if(br.hasErrors())
	{
		return "redirect:/adminpage";
	}
	else
	{
	service.getUpdate(admin);
    return "redirect:/account";
	}
	
}

}
