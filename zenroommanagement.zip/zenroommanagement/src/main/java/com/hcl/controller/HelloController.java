package com.hcl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
 @RequestMapping(value={"/","/index"}, method = RequestMethod.GET)
 public String getHome()
 {
	 return "index";
 }
 @RequestMapping(value="/gallery", method = RequestMethod.GET)
 public String getGallery()
 {
	 return "gallery";
 }
 @RequestMapping(value="/rule", method = RequestMethod.GET)
 public String getRule()
 {
	 return "rule";
 }
 @RequestMapping(value="/aboutus", method = RequestMethod.GET)
 public String getAboutus()
 {
	 return "aboutus";
 }
 @RequestMapping(value="/contactus", method = RequestMethod.GET)
 public String getContactus()
 {
	 return "contactus";
 }
 @RequestMapping(value="/reserve", method = RequestMethod.GET)
 public String getReserve()
 {
	 return "reserve";
 }
 @RequestMapping(value="/admin", method = RequestMethod.GET)
 public String getAdmin()
 {
	 return "admin";
 }
 @RequestMapping(value="/success", method = RequestMethod.GET)
 public String getSuccess()
 {
	 return "success";
 }
 @RequestMapping(value="/adminpage", method = RequestMethod.GET)
 public String getLogin()
 {
	 return "adminpage";
 }
 @RequestMapping(value="/adminhome", method = RequestMethod.GET)
 public String getAdminLogin()
 {
	 return "adminpage";
 }
 @RequestMapping(value="/logout", method = RequestMethod.GET)
 public String getLogout()
 {
	 return "index";
 }
}
