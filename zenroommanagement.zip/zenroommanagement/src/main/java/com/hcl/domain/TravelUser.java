package com.hcl.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="traveluser")
public class TravelUser {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
  Integer travel_id;
  Integer room_id;
  String firstname;
  String middlename;
  String lastname;
  String address;
  String contactno;
  String checkin;
  String checkout;
  public TravelUser() {
	// TODO Auto-generated constructor stub
}
public TravelUser(Integer travel_id, Integer room_id, String firstname, String middlename, String lastname,
		String address, String contactno, String checkin, String checkout) {
	super();
	this.travel_id = travel_id;
	this.room_id = room_id;
	this.firstname = firstname;
	this.middlename = middlename;
	this.lastname = lastname;
	this.address = address;
	this.contactno = contactno;
	this.checkin = checkin;
	this.checkout = checkout;
}
public Integer getTravel_id() {
	return travel_id;
}
public void setTravel_id(Integer travel_id) {
	this.travel_id = travel_id;
}
public Integer getRoom_id() {
	return room_id;
}
public void setRoom_id(Integer room_id) {
	this.room_id = room_id;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getMiddlename() {
	return middlename;
}
public void setMiddlename(String middlename) {
	this.middlename = middlename;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public String getCheckin() {
	return checkin;
}
public void setCheckin(String checkin) {
	this.checkin = checkin;
}
public String getCheckout() {
	return checkout;
}
public void setCheckout(String checkout) {
	this.checkout = checkout;
}
  

}
