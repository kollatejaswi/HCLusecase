package com.hcl.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;


@Entity
@Table(name="adminlogin")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
 Integer id;
@NotEmpty(message="please fill the field")
 String username;
@NotEmpty(message="please fill the field")
 String password;
 public Admin() {
	// TODO Auto-generated constructor stub
}
public Admin(Integer id, String username, String password) {
	super();
	this.id = id;
	this.username = username;
	this.password = password;
}
public Admin(String username, String password) {
	super();
	this.username = username;
	this.password = password;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
 
}
