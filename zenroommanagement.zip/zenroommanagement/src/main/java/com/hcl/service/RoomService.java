package com.hcl.service;

import java.util.List;

import com.hcl.domain.Room;

public interface RoomService {
  public List<Room> getAll();
}
