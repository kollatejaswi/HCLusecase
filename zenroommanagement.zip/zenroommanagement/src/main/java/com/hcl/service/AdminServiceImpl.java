package com.hcl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.AdminDao;
import com.hcl.domain.Admin;
@Service
public class AdminServiceImpl implements AdminService {
  AdminDao dao;
    @Autowired
	public AdminServiceImpl(AdminDao dao) {
	super();
	this.dao = dao;
}

	@Override
	public boolean login(Admin a) {
		// TODO Auto-generated method stub
		return dao.login(a);
	}

	@Override
	public List<Admin> getAll() {
		// TODO Auto-generated method stub
		return dao.getall();
	}

	@Override
	public Integer insert(Admin a) {
	
		return dao.insert(a);
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Admin getAdmin(Integer id) {
		
		return dao.getAdmin(id);
	}

	@Override
	public Admin getUpdate(Admin a) {
		// TODO Auto-generated method stub
		return dao.getUpdate(a);
	}

}
