package com.hcl.service;

import java.util.List;

import com.hcl.domain.Travel;

public interface TravelService {
      Integer insertTravel(Travel t);
      List<Travel> getAll();
}
