package com.hcl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.TravelDao;
import com.hcl.domain.Travel;
@Service
public class TravelServiceImpl implements TravelService {
  private TravelDao dao;
  @Autowired
	public TravelServiceImpl(TravelDao dao) {
	super();
	this.dao = dao;
}

	@Override
	public Integer insertTravel(Travel t) {
	
		return dao.insert(t);
	}

	@Override
	public List<Travel> getAll() {
		
		return dao.getAll();
	}

}
