package com.hcl.service;

import com.hcl.domain.TravelUser;

public interface TravelUserService {
	Integer insertTravel(TravelUser t);
}
