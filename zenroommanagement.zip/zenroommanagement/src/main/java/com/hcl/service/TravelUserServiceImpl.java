package com.hcl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.TravelUserDao;
import com.hcl.domain.TravelUser;
@Service
public class TravelUserServiceImpl implements TravelUserService {
  TravelUserDao dao;
   @Autowired
	public TravelUserServiceImpl(TravelUserDao dao) {
	super();
	this.dao = dao;
}

	@Override
	public Integer insertTravel(TravelUser t) {
		
		return dao.insert(t);
	}

}
