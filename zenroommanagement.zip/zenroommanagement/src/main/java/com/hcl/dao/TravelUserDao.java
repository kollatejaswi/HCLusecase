package com.hcl.dao;

import com.hcl.domain.TravelUser;

public interface TravelUserDao {
	Integer insert(TravelUser t);
}
