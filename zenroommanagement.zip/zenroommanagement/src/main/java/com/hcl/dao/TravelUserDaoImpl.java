package com.hcl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.domain.TravelUser;
@Repository
public class TravelUserDaoImpl implements TravelUserDao {
	private SessionFactory sessionfactory;
   @Autowired
	public TravelUserDaoImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;
	}
    @Transactional
	@Override
	public Integer insert(TravelUser t) {
		Session session=sessionfactory.getCurrentSession();
        Integer i=(Integer)session.save(t);
		return i;
	}

}
