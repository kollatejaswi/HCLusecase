package com.hcl.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.domain.Room;
@Component
public class RoomDaoImpl implements RoomDao {
     private SessionFactory sessionfactory;
    
    @Autowired
	public RoomDaoImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;
	}

    @Transactional
	@Override
	public List<Room> getAll() {
		Session session=sessionfactory.getCurrentSession();
		Query query=session.createQuery("select r from com.hcl.domain.Room as r ");
		List<Room> em=query.list();
		return em;
		}

}
