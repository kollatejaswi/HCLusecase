package com.hcl.dao;

import java.util.List;

import com.hcl.domain.Travel;

public interface TravelDao {
    Integer insert(Travel t);
    List<Travel> getAll();
}
