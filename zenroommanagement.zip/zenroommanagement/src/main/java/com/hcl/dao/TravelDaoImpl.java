package com.hcl.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.domain.Room;
import com.hcl.domain.Travel;
@Repository
public class TravelDaoImpl implements TravelDao {
	private SessionFactory sessionfactory;
   @Autowired
	public TravelDaoImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;
	}
    @Transactional
	@Override
	public Integer insert(Travel t) {
		Session session=sessionfactory.getCurrentSession();
        Integer i=(Integer)session.save(t);
		return i;
	}
    @Transactional
	@Override
	public List<Travel> getAll() {
		Session session=sessionfactory.getCurrentSession();
		Query query=session.createQuery("select r from com.hcl.domain.Travel as r ");
		List<Travel> em=query.list();
		return em;
	}

}
