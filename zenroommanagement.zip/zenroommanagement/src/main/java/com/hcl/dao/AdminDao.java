package com.hcl.dao;

import java.util.List;

import com.hcl.domain.Admin;

public interface AdminDao {
  boolean login(Admin a);
  List<Admin> getall();
  Integer insert(Admin a);
  void delete(Integer id);
 public Admin getAdmin(Integer id);
  public Admin getUpdate(Admin a);
}
