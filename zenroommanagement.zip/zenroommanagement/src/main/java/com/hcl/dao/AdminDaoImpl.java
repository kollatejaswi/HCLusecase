package com.hcl.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.domain.Admin;
import com.hcl.domain.Room;
@Repository
public class AdminDaoImpl implements AdminDao {
	private SessionFactory sessionfactory;
	@Autowired
	public AdminDaoImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;
	}
    @Transactional
	@Override
	public boolean login(Admin a) {
		boolean b=false;
		Session session=sessionfactory.getCurrentSession();
		String hql = "from com.hcl.domain.Admin where username = ?0 and password = ?1";  
		Query query=session.createQuery(hql);
		query.setParameter(0, a.getUsername());
		query.setParameter(1, a.getPassword());
		List <Admin> list=query.list();
		if(list.size()>0)
		{
			b=true;
		}
		return b;
	}
    @Transactional
	@Override
	public List<Admin> getall() {
		Session session=sessionfactory.getCurrentSession();
		Query query=session.createQuery("select r from com.hcl.domain.Admin as r ");
		List<Admin> em=query.list();
		return em;
	}
    @Transactional
	@Override
	public Integer insert(Admin a) {
    	Session session=sessionfactory.getCurrentSession();
    	Integer i=(Integer)session.save(a);
		return i;
	}
    @Transactional
	@Override
	public void delete(Integer id) {
		Session session=sessionfactory.getCurrentSession();
		Admin admin = (Admin) session.load(Admin.class,id);
		if(admin!=null)
		{
			session.delete(admin);
		}
	}
    @Transactional 
	@Override
	public Admin getAdmin(Integer id) {
		Session session=sessionfactory.getCurrentSession();
		Admin admin =  session.get(Admin.class, id);
		return admin;
	}
    @Transactional
	@Override
	public Admin getUpdate(Admin a) {
    	sessionfactory.getCurrentSession().update(a);

		return a;
	}

}
