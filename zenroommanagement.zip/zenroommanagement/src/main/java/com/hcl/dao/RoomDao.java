package com.hcl.dao;

import java.util.List;

import com.hcl.domain.Room;

public interface RoomDao {
public	List<Room> getAll();

}
